"""ZWCAD Worker schema placeholder."""
