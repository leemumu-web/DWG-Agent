"""Local storage adapter placeholder."""
